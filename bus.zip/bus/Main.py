import bus.service as service

if __name__ == '__main__':
    serv = service.BusService()
    # serv.getBusInfo()
    serv.getBusRoute()